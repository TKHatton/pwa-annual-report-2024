# PWA Annual Report Website Deployment Guide

This guide will walk you through the process of deploying the PWA Annual Report website using GitHub and Netlify. These instructions assume you already have accounts with both services.

## Step 1: Log into GitHub

1. Open your web browser and go to [GitHub.com](https://github.com)
2. Click the "Sign in" button in the top-right corner
3. Enter your username or email address and password
4. Click "Sign in"

## Step 2: Create a New Repository on GitHub

1. Once logged in, click on the "+" icon in the top-right corner of the page
2. Select "New repository" from the dropdown menu
3. Fill in the repository details:
   - Repository name: `pwa-annual-report-2024` (or any name you prefer)
   - Description: "Interactive Annual Report 2024 for Positive Wellness Alliance"
   - Choose "Public" (unless you want to keep it private)
   - Check the box for "Add a README file"
4. Click the "Create repository" button

## Step 3: Upload the Website Files to GitHub

1. In your new repository, click on the "Add file" button and select "Upload files"
2. Drag and drop all the website files and folders from your computer, or click to browse and select them
   - Make sure to include: index.html, styles.css, scripts.js, and the images folder
3. Scroll down and add a commit message like "Initial upload of PWA Annual Report website"
4. Click the "Commit changes" button

## Step 4: Log into Netlify

1. Open a new browser tab and go to [Netlify.com](https://netlify.com)
2. Click the "Log in" button in the top-right corner
3. Choose to log in with GitHub (recommended) or enter your Netlify email and password
4. Complete any authentication steps required

## Step 5: Create a New Site on Netlify

1. Once logged in to Netlify, click the "Add new site" button
2. Select "Import an existing project" from the options
3. Choose "GitHub" as your Git provider
4. You may need to authorize Netlify to access your GitHub account if you haven't done so before
5. Find and select the `pwa-annual-report-2024` repository you just created
6. In the site settings:
   - Build command: Leave blank (not needed for static HTML sites)
   - Publish directory: Leave blank (it will use the root directory)
7. Click the "Deploy site" button

## Step 6: Wait for Deployment and Check Your Site

1. Netlify will begin deploying your site - this usually takes less than a minute
2. Once deployment is complete, Netlify will provide you with a random URL (like "random-words-123456.netlify.app")
3. Click on this URL to view your deployed website
4. Check that everything looks correct and all features are working

## Step 7: Customize Your Site URL (Optional)

1. From your Netlify dashboard, click on your new site
2. Go to "Site settings" and then "Domain management"
3. Under "Custom domains", click "Add custom domain"
4. You can either:
   - Change the Netlify subdomain to something more memorable (like "pwa-annual-report-2024.netlify.app")
   - Connect a domain you already own (this requires additional DNS configuration)
5. Follow the on-screen instructions to complete the process

## Step 8: Make Updates to Your Website (If Needed)

If you need to make changes to your website after deployment:

1. Make the necessary changes to the files on your computer
2. Go to your GitHub repository
3. Click "Add file" and "Upload files" again
4. Upload the modified files
5. Add a commit message describing your changes
6. Click "Commit changes"
7. Netlify will automatically detect the changes and redeploy your site (usually within a minute)

## Troubleshooting

If you encounter any issues during deployment:

- **Files not showing up**: Make sure you uploaded all necessary files, including the images folder
- **Styling issues**: Verify that the styles.css file was uploaded correctly
- **JavaScript not working**: Check that scripts.js was uploaded and that there are no console errors
- **Deployment failed**: Check Netlify's deploy log for specific error messages

## Getting Help

If you need additional assistance:

- Netlify Documentation: [https://docs.netlify.com/](https://docs.netlify.com/)
- GitHub Documentation: [https://docs.github.com/](https://docs.github.com/)
- Contact your website developer for specific questions about the PWA Annual Report website
